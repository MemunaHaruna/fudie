FactoryBot.define do
  factory :vote do
    vote_type { 1 }
    post
    user
  end
end
