FactoryBot.define do
  factory :thread_following do
    user
    post
  end
end
