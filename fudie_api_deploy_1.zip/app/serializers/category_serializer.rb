class CategorySerializer < ActiveModel::Serializer
  attributes :id, :name
end
