class ApplicationMailer < ActionMailer::Base
  default from: 'memunaharuna16@gmail.com'
  layout 'mailer'
end
